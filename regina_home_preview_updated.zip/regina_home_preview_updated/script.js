// Aquí puedes añadir interacciones JS si las necesitas
console.log("Regina Interior Design - Preview Loaded");
